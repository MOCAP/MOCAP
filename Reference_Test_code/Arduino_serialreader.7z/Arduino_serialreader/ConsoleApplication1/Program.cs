﻿#region Namespace Inclusions
using System;
using System.Data;
using System.IO.Ports;
using System.Windows.Forms;
using System.Data.SQLite;
using System.Text.RegularExpressions;
using System.Collections;
#endregion

namespace SerialPortExample
{
    class SerialPortProgram
    {
        // Create the serial port with basic settings
        private SerialPort port = new SerialPort("COM3",9600, Parity.None, 8, StopBits.One);

        private static SQLiteConnection sqlite_DB;
        private static SQLiteDataAdapter ad;
        private static Queue input_queue;
        private static int Session_ID;

        private SerialPortProgram()
        {
            Console.WriteLine("Program Start");
            // Attach a method to be called when there
            // is data waiting in the port's buffer
            port.DataReceived += new
              SerialDataReceivedEventHandler(port_DataReceived);
            port.DtrEnable = true;
            // Begin communications
            port.Open();

            input_queue = new Queue();

        }

        [STAThread]
        static void Main(string[] args)
        {
            new SerialPortProgram();

            string path = "F:\\Dropbox\\Shared_data\\FYDP\\nineDOF_raw\\MPU9150_raw";
            sqlite_DB = new SQLiteConnection("Data Source=" + path + "\\arduino_data.db");
            // Instatiate this class
            Console.WriteLine("Data Source=" + path + "\\arduino_data.db");
            sqlite_DB.Open();

            SQLiteCommand cmd;
            cmd = sqlite_DB.CreateCommand();
            string query = "SELECT MAX(SessionID) AS MaxSessionID FROM arduino_data";
            cmd.CommandText = query;

            ad = new SQLiteDataAdapter(cmd);
            DataTable dt = new DataTable();

            ad.Fill(dt);

            if (dt.Rows.Count > 0) // Check if the DataTable returns any data from database
            {
                string val = dt.Rows[0]["MaxSessionID"].ToString(); // Where Fieldname is the name of fields from your database that you want to get
                Session_ID = Convert.ToInt32(val) + 1;
                Console.WriteLine(Session_ID);
            }

            // Enter an application loop to keep this thread alive

            Application.Run();

            while (false)
            {
                /**/
            }

        }

        private void port_DataReceived(object sender,
          SerialDataReceivedEventArgs e)
        {
            string input = port.ReadLine();
            Match match = Regex.Match(input, @"Time:(\d*).*a\/g\/m:(\d*)\|(-?\d*)\|(-?\d*)\|(-?\d*)\|(-?\d*)\|(-?\d*)\|(-?\d*)\|(-?\d*)\|(-?\d*)");

            if (match.Success)
            {
                Console.WriteLine(input);
                string milliseconds = match.Groups[1].Value;
                string ax = match.Groups[2].Value;
                string ay = match.Groups[3].Value;
                string az = match.Groups[4].Value;
                string gx = match.Groups[5].Value;
                string gy = match.Groups[6].Value;
                string gz = match.Groups[7].Value;
                string mx = match.Groups[8].Value;
                string my = match.Groups[9].Value;
                string mz = match.Groups[10].Value;
                string sDate = DateTime.Now.ToString();
                sDate = "\"" + sDate + "\"";

                string query = string.Format("INSERT INTO arduino_data Values({0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11})",Session_ID,sDate,milliseconds,ax,ay,az,gx,gy,gz,mx,my,mz);
                Console.WriteLine(query);
                ad.InsertCommand = new SQLiteCommand(query, sqlite_DB);
                ad.InsertCommand.ExecuteNonQuery();
            }
            //Console.WriteLine(input);
        }
    }
}